﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CryptoGraphy
{

    public class FAFEncryption : ConfigurationSection
    {
        [ConfigurationProperty("FAFEncryptionNameValues")]
        public FAFEncryptionElementValueStrCollection HashKeys
        {
            get { return ((FAFEncryptionElementValueStrCollection)(base["FAFEncryptionNameValues"])); }
        }

        [ConfigurationProperty("FAFEncryptionNameValueStrings")]
        public FAFEncryptionElementValueStrCollection HashConnKeys
        {
            get { return ((FAFEncryptionElementValueStrCollection)(base["FAFEncryptionNameValueStrings"])); }
        }
    }



    public class FAFEncryptionNameValueStrings : ConfigurationSection
    {
        [ConfigurationProperty("FAFEncryptionNameValueStrings")]
        public FAFEncryptionElementValueStrCollection HashConnKeys
        {
            get { return ((FAFEncryptionElementValueStrCollection)(base["FAFEncryptionNameValueStrings"])); }
        }
    }


    /// <summary/
    /// The collection class that will store the list of each element/item that
    /// is returned back from the configuration manager.
    /// </summary>
    [ConfigurationCollection(typeof(FAFEncryptionElement))]
    public class FAFEncryptionElementCollection : ConfigurationElementCollection
    {
        protected override ConfigurationElement CreateNewElement()
        {
            return new FAFEncryptionElement();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((FAFEncryptionElement)(element)).Key;
        }

        public FAFEncryptionElement this[int idx]
        {
            get
            {
                return (FAFEncryptionElement)BaseGet(idx);
            }
        }
    }

    /// <summary>
    /// The class that holds onto each element returned by the configuration manager.
    /// </summary>
    public class FAFEncryptionElement : ConfigurationElement
    {
        [ConfigurationProperty("key", DefaultValue = "", IsKey = true, IsRequired = true)]
        public string Key
        {
            get
            {
                return ((string)(base["key"]));
            }
            set
            {
                base["key"] = value;
            }
        }

        [ConfigurationProperty("value", DefaultValue = "", IsKey = false, IsRequired = false)]
        public string Value
        {
            get
            {
                return ((string)(base["value"]));
            }
            set
            {
                base["value"] = value;
            }
        }
    }


    [ConfigurationCollection(typeof(FAFEncryptionElementConnStr), AddItemName = "add", ClearItemsName = "clear", RemoveItemName = "remove")]
    public class FAFEncryptionElementValueStrCollection : ConfigurationElementCollection
    {
        protected override ConfigurationElement CreateNewElement()
        {
            return new FAFEncryptionElementConnStr();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((FAFEncryptionElementConnStr)(element)).Key;
        }

        public FAFEncryptionElementConnStr this[int idx]
        {
            get
            {
                return (FAFEncryptionElementConnStr)BaseGet(idx);
            }
        }

        new public FAFEncryptionElementConnStr this[string key]
        {
            get
            {
                return (FAFEncryptionElementConnStr)BaseGet(key);
            }
        }
    }

    /// <summary>
    /// The class that holds onto each element returned by the configuration manager.
    /// </summary>
    public class FAFEncryptionElementConnStr : ConfigurationElement
    {
        [ConfigurationProperty("key", DefaultValue = "", IsKey = true, IsRequired = true)]
        public string Key
        {
            get
            {
                return ((string)(base["key"]));
            }
            set
            {
                base["key"] = value;
            }
        }

        [ConfigurationProperty("value", DefaultValue = "", IsKey = false, IsRequired = true)]
        public string Value
        {
            get
            {
                return ((string)(base["value"]));
            }
            set
            {
                base["value"] = value;
            }
        }

        [ConfigurationProperty("namevaluedelimitter", DefaultValue = "", IsKey = true, IsRequired = false)]
        public char Namevaluedelimitter
        {
            get
            {
                return ((char)(base["namevaluedelimitter"]));
            }
            set
            {
                base["namevaluedelimitter"] = value;
            }
        }

        [ConfigurationProperty("itemdelimitter", DefaultValue = "", IsKey = false, IsRequired = false)]
        public char Itemdelimitter
        {
            get
            {
                return ((char)(base["itemdelimitter"]));
            }
            set
            {
                base["itemdelimitter"] = value;
            }
        }
    }
}
