﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace CryptoGraphy
{

    public class FACCUtil
    {
        public const string CF_ControlFilesBase = "ControlFilesBase";
        public const string CF_ClearCacheInterval = "ClearCacheInterval";
        public const string CF_ClearCacheArray = "ClearCacheArray";
        public const string FAF_EVENT_SOURCE = "FAF";

        //private static string s_FileBasePath;
        //private static string s_WriteFileFolder;
        //private static bool? s_DemonstrationMode = null;
        //private static string s_DemonstrationModeWaterMarkText = null;
        //private static string s_DemonstrationModeLoginMessage = null;
        //private static ILogger logger = FAFLoggerFactory.GetLogger(typeof(ANUtils));
        private const string s_PublicKey = "f@ha@g3ntn3t1143@$tf1fth$tr33t0c";
        private const string s_Encryption = "FAFEncryptionMode";
        private static bool s_EncryptionModeOn = false;
        public const string s_HexBegin = "$/FACC/";
        private const string s_originalKey = "G0H0051ers";


        //protected static SymmetricAlgorithm _symmetricAlgorithm;
        //private static string sEncrptionKey = "0095549538076800";
        //private static string sEncryptionVector = "27451849";

        private static string KeyHexString = "98fbb60a54075eaac7d40a9df9431810f4d0982f8419ffda8a673f62713118ee";
        private static string IVHexString = "6eee02310e66a7f24432b3ff7a6afb83";

        /* ALL files reads are based on the below base ffolder */
        static FACCUtil()
        {
            //s_FileBasePath = GetConfig(CF_ControlFilesBase);
            //if (Constants.ANUTILS_WRITE_FILE_FOLDER.Length > 0)
            //    s_WriteFileFolder = Constants.ANUTILS_WRITE_FILE_FOLDER;
            //else
            //    s_WriteFileFolder = s_FileBasePath;

            // New App settings to set FAFEncryptionMode - True / False
            //_symmetricAlgorithm = FACCUtil.GetSymmetricAlgorithm();
            //_symmetricAlgorithm.Mode = CipherMode.CBC;
            //_symmetricAlgorithm.Padding = PaddingMode.PKCS7;
            
                s_EncryptionModeOn =true;
            //SaveTimeZoneInfo();
        }
        //public static SymmetricAlgorithm GetSymmetricAlgorithm()
        //{
        //    return new TripleDESCryptoServiceProvider();
        //}
        public static bool IsConfig(string key)
        {
            bool returnValue = false;
            if (ConfigurationManager.AppSettings[key] == null)
            {
                // To get the decrypted value from custom configuration section
                if (s_EncryptionModeOn == true)
                {
                    string strValue = GetEncryptedConfig(key);
                    if (strValue != null)
                    {
                        returnValue = true;
                    }
                }
            }
            else
            {
                returnValue = true;
            }

            return returnValue;
        }
        public static string GetConfig(string key)
        {
            if (ConfigurationManager.AppSettings[key] == null)
            {

                // To get the decrypted value from custom configuration section
                if (s_EncryptionModeOn == true)
                {
                    string strValue = GetEncryptedConfig(key);
                    if (strValue != null)
                        return strValue;
                }

                string message = string.Format("AppSetting Configuration Key [{0}] not found.", key);
                //WriteNTEventLog(message);
                //Dictionary<string, string> values = new Dictionary<string, string>();
                //values.Add("Key", key);
                //throw new AgentNetException(LoggingUtils.UnexpectedException(MethodBase.GetCurrentMethod(), message, values));
                throw new Exception(message);
            }
            else
            {
                return ConfigurationManager.AppSettings[key];
            }

        }
        private static string GetEncryptedConfig(string key)
        {
            string strTemp = null;

            try
            {
                strTemp = GetEncryptedValueForKey(key);

            }
            catch (Exception ex)
            {
                string message = string.Format("Connection String not found");
                //Dictionary<string, string> values = new Dictionary<string, string>();
                //values.Add("Key", key);
                //throw new AgentNetException(LoggingUtils.UnexpectedException(MethodBase.GetCurrentMethod(), message, values), ex);
                throw new Exception(message);
            }

            return strTemp;
        }
        // Get the value from the FAFEncryptionMode - keys
        private static string GetEncryptedValueForKey(string key)
        {
            try
            {
                
                    return GetEncryptedValueforKeyString(key);
            }

            catch (Exception ex)
            {
                    throw new Exception("Connection String not found");
            }

        }
        public static byte[] StringToByteArray(String hex)
        {
            int NumberChars = hex.Length;
            byte[] bytes = new byte[NumberChars / 2];
            for (int i = 0; i < NumberChars; i += 2)
                bytes[i / 2] = Convert.ToByte(hex.Substring(i, 2), 16);
            return bytes;
        }
        public static string GetDecrypted(string cipherString, string key)
        {
            try
            {
                /*  byte[] keyArray;
                  byte[] toEncryptArray = Convert.FromBase64String(cipherString);

                  if (key == null || key.Length <= 0)
                      key = s_PublicKey;

                  //if hashing was used get the hash code with regards to your key
                  MD5CryptoServiceProvider hashmd5 = new MD5CryptoServiceProvider();
                  keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(key));
                  hashmd5.Clear();

                  TripleDESCryptoServiceProvider tdes = new TripleDESCryptoServiceProvider();

                  //set the secret key for the tripleDES algorithm
                  tdes.Key = keyArray;

                  //mode of operation. there are other 4 modes. We choose ECB(Electronic code Book)
                  tdes.Mode = CipherMode.ECB;

                  //padding mode(if any extra byte added)
                  tdes.Padding = PaddingMode.PKCS7;

                  ICryptoTransform cTransform = tdes.CreateDecryptor();
                  byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);

                  //Release resources held by TripleDes Encryptor                
                  tdes.Clear();

                  //return the Clear decrypted TEXT
                  return resultArray;*/

                byte[] decryptString = StringToByteArray(cipherString);
                byte[] decryptKey = StringToByteArray(KeyHexString);
                byte[] vector = StringToByteArray(IVHexString);

                return DecryptStringFromBytes(decryptString, decryptKey, vector);
                //ASCIIEncoding aSCIIEncoding = new ASCIIEncoding();
                //UnicodeEncoding unicodeEncoding = new UnicodeEncoding();
                //string result = "";
                //byte[] bytes;

                //byte[] buffer = Convert.FromBase64String(cipherString);
                //_symmetricAlgorithm.Key = aSCIIEncoding.GetBytes(sEncrptionKey);
                //_symmetricAlgorithm.IV = aSCIIEncoding.GetBytes(sEncryptionVector);
                //ICryptoTransform cryptoTransform = _symmetricAlgorithm.CreateDecryptor();
                //bytes = cryptoTransform.TransformFinalBlock(buffer, 0, buffer.Length);

                //result = unicodeEncoding.GetString(bytes);
                //return result;


            }
            catch (Exception ex)
            {
                //logger.Error("ANUtils.Decrypt exeception: " + ex.ToString());
                throw new Exception("ANUtils.Decrypt exeception: " + ex.ToString());
            }
            return null;
        }
        //  Decrypt the Connection string
        private static string GetEncryptedValueforKeyString(string strConn)
        {
            try
            {              

             
                    string encConnection = ConfigurationManager.ConnectionStrings[strConn].ConnectionString;

                    StringBuilder strBuild = new StringBuilder();

                    int findIndex = encConnection.IndexOf('=');
                    string strEncrypted;

                while (findIndex > 0)
                {
                    strBuild.Append(encConnection.Substring(0, findIndex + 1));
                    encConnection = encConnection.Substring(findIndex + 1);
                    findIndex = encConnection.IndexOf(';');

                    if (findIndex > 0)
                        strEncrypted = encConnection.Substring(0, findIndex);
                    else
                        strEncrypted = encConnection.Substring(0, encConnection.Length);

                    if (strEncrypted.StartsWith(s_HexBegin))
                    {
                        strEncrypted = strEncrypted.Replace(s_HexBegin, string.Empty);
                        // strEncrypted = Convert.ToBase64String(FACCUtil.StringToByteArray(strEncrypted));
                        strBuild.Append(FACCUtil.GetDecrypted(strEncrypted, string.Empty));
                    }
                    else
                        strBuild.Append(strEncrypted);

                    if (findIndex > 0)
                    {
                        strBuild.Append(';');
                        encConnection = encConnection.Substring(findIndex + 1);
                    }
                    else
                        encConnection = string.Empty;

                    findIndex = encConnection.IndexOf('=');
                }
                    

                    return strBuild.ToString();
                
            }
            catch (Exception ex)
            {
                               throw new Exception("Connection String not found");

            }

            return null;

        }


        public static byte[] EncryptStringToBytes(string plainText, byte[] Key, byte[] IV)
        {
            if (plainText == null || plainText.Length <= 0)
                throw new ArgumentNullException("plainText");
            if (Key == null || Key.Length <= 0)
                throw new ArgumentNullException("Key");
            if (IV == null || IV.Length <= 0)
                throw new ArgumentNullException("Key");
            byte[] encrypted;
            using (RijndaelManaged rijAlg = new RijndaelManaged())
            {
                rijAlg.Key = Key;
                rijAlg.IV = IV;
                ICryptoTransform encryptor = rijAlg.CreateEncryptor(rijAlg.Key, rijAlg.IV);
                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {
                            swEncrypt.Write(plainText);
                        }
                        encrypted = msEncrypt.ToArray();
                    }
                }
            }
            return encrypted;
        }
        public static string DecryptStringFromBytes(byte[] cipherText, byte[] Key, byte[] IV)
        {
            if (cipherText == null || cipherText.Length <= 0)
                throw new ArgumentNullException("cipherText");
            if (Key == null || Key.Length <= 0)
                throw new ArgumentNullException("Key");
            if (IV == null || IV.Length <= 0)
                throw new ArgumentNullException("Key");
            string plaintext = null;
            using (RijndaelManaged rijAlg = new RijndaelManaged())
            {
                rijAlg.Key = Key;
                rijAlg.IV = IV;
                ICryptoTransform decryptor = rijAlg.CreateDecryptor(rijAlg.Key, rijAlg.IV);
                using (MemoryStream msDecrypt = new MemoryStream(cipherText))
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                        {
                            plaintext = srDecrypt.ReadToEnd();
                        }
                    }
                }

            }

            return plaintext;
        }

    }
}
