﻿using Microsoft.AspNet.Identity;
using SecurityChallenge.FAI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;

namespace SecurityChallenge.FAI.Controllers
{
    [Authorize]
    [HandleError]
    public class CreateCharacterController : Controller
    {
        // GET: CreateCharacter
        public ActionResult Index()
        {
            CreateUserCharacterViewModel obj = new CreateUserCharacterViewModel();
            obj.CharacterView = new List<CharacterViewModel>();
            using (var context = new securitychallengeEntities())
            {
                int userid = Convert.ToInt32(User.Identity.GetUserId());
                var result = context.Tbl_User_Charcter.Where(x => x.User_ID == userid).ToList();
                foreach(var item in result)
                {
                    CharacterViewModel ob = new CharacterViewModel();
                    ob.Id = item.Id;
                    ob.Character_Name = item.Tbl_Character.Character_Name;
                    ob.Description = item.Description;
                    obj.CharacterView.Add(ob);
                }
                obj.Character = context.Tbl_Character.Select(x => new SelectListItem
                {
                    Value = x.Id.ToString(),
                    Text = x.Character_Name
                }).ToList();
            }
            return View(obj);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index([Bind(Include = "Character_ID,Character_Name,Description")] CreateUserCharacter objpr)
        {
            CreateUserCharacterViewModel objp = new CreateUserCharacterViewModel();
            objp.CharacterView = new List<CharacterViewModel>();
            using (var context = new securitychallengeEntities())
            {
                int userid = Convert.ToInt32(User.Identity.GetUserId());
                var result1 = context.Tbl_User_Charcter.ToList();
                var list = result1.Where(m => m.Description.ToUpper() == objpr.Description.ToUpper()&&m.User_ID== userid).FirstOrDefault();
                var list1 = result1.Where(m => m.Character_ID == objpr.Character_ID && m.User_ID == userid).FirstOrDefault();
                var limit = result1.Where(m => m.User_ID == userid).ToList().Count;
                var userlimit = context.USERS.Where(x => x.UserId == userid).FirstOrDefault().MaxCharacter;
                if (list != null)
                {
                    var result = context.Tbl_User_Charcter.Where(x => x.User_ID == userid).ToList();
                    foreach (var item in result)
                    {
                        CharacterViewModel ob = new CharacterViewModel();
                        ob.Id = item.Id;
                        ob.Character_Name = item.Tbl_Character.Character_Name;
                        ob.Description = item.Description;
                        objp.CharacterView.Add(ob);
                    }
                    objp.Character = context.Tbl_Character.Select(x => new SelectListItem
                    {
                        Value = x.Id.ToString(),
                        Text = x.Character_Name
                    }).ToList();
                    ModelState.AddModelError("", "Description Already in use");
                    return View(objp);
                }
                else if(list1 != null)
                {
                    var result = context.Tbl_User_Charcter.Where(x => x.User_ID == userid).ToList();
                    foreach (var item in result)
                    {
                        CharacterViewModel ob = new CharacterViewModel();
                        ob.Id = item.Id;
                        ob.Character_Name = item.Tbl_Character.Character_Name;
                        ob.Description = item.Description;
                        objp.CharacterView.Add(ob);
                    }
                    objp.Character = context.Tbl_Character.Select(x => new SelectListItem
                    {
                        Value = x.Id.ToString(),
                        Text = x.Character_Name
                    }).ToList();

                    ModelState.AddModelError("", "Class Already in use");
                    return View(objp);
                }
                else if(userlimit<limit)
                {
                    var result = context.Tbl_User_Charcter.Where(x => x.User_ID == userid).ToList();
                    foreach (var item in result)
                    {
                        CharacterViewModel ob = new CharacterViewModel();
                        ob.Id = item.Id;
                        ob.Character_Name = item.Tbl_Character.Character_Name;
                        ob.Description = item.Description;
                        objp.CharacterView.Add(ob);
                    }
                    objp.Character = context.Tbl_Character.Select(x => new SelectListItem
                    {
                        Value = x.Id.ToString(),
                        Text = x.Character_Name
                    }).ToList();

                    ModelState.AddModelError("", "You Have Reached The Maximum Limit");
                    return View(objp);
                }
                else
                {
                    string desc=Regex.Replace(objpr.Description, @"\s+", " ");
                    Tbl_User_Charcter obj = new Tbl_User_Charcter();
                    obj.Character_ID = objpr.Character_ID;
                    obj.User_ID = userid;
                    obj.Character_Name = objpr.Character_Name;
                    obj.Description = desc;
                    var user = context.Tbl_User_Charcter.Add(obj);
                    context.SaveChanges();
                }
            }
            return RedirectToAction("Index", "CreateCharacter");
        }
    }
}