﻿using SecurityChallenge.FAI.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SecurityChallenge.FAI.Controllers
{
    [Authorize(Roles = "Admin")]
    [HandleError]
    public class ManageUsersController : Controller
    {
        // GET: ManageUsers
        public ActionResult Index()
        {
            List<UserDTO> User = new List<UserDTO>();
            using (var context = new securitychallengeEntities())
            {
                var list = context.USERS.Where(x=> x.UserRoles.FirstOrDefault().ROLE.RoleId!=4).ToList();
                foreach (var item in list)
                {
                    UserDTO obj = new UserDTO();
                    obj.UserId = item.UserId;
                    obj.Username = item.UserName;
                    obj.PhoneNumber = item.PhoneNumber;
                    obj.Email = item.Email;
                    obj.MaxCharacter = item.MaxCharacter;
                    obj.Character = Getcharacterlist(item.Tbl_User_Charcter.ToList());
                    obj.CharacterId= Getcharactername(item.UserCharacters.ToList()).Id;
                    User.Add(obj);
                }
            }
            return View(User);
        }
        private string Getcharacterlist(List<Tbl_User_Charcter> list)
        {
            string characterlist = "";
            foreach (var item in list)
            {
                characterlist+=(item.Description)+",";
            }
            return characterlist.Remove(characterlist.Length - 1); 
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index([Bind(Include = "UserId,Username,Email,PhoneNumber,MaxCharacter")] AddCharacter objpr)
        {
            using (var context = new securitychallengeEntities())
            {
                if (objpr.UserId == null)
                {
                    USER obj = new USER();
                    obj.Email = objpr.Email;
                    obj.UserName = objpr.Username;
                    obj.PhoneNumber = objpr.PhoneNumber;
                    obj.MaxCharacter = objpr.MaxCharacter;
                    var user = context.USERS.Add(obj);
                    context.SaveChanges();
                }
                else
                {
                    var obj = context.USERS.Where(x => x.UserId == objpr.UserId).FirstOrDefault();
                    if (obj != null)
                    {
                        obj.Email = objpr.Email;
                        obj.UserName = objpr.Username;
                        obj.PhoneNumber = objpr.PhoneNumber;
                        obj.MaxCharacter = objpr.MaxCharacter;
                        var user = context.USERS.Add(obj);
                        context.Entry(obj).State = EntityState.Modified;
                        context.SaveChanges();
                        var list = context.UserCharacters.Where(x => x.User_Id == objpr.UserId).ToList();
                        context.UserCharacters.RemoveRange(list);
                        context.SaveChanges();
                        List<UserCharacter> ob = new List<UserCharacter>();
                        if (objpr.SelectedIds != null)
                        {
                            for (int i = 0; i < objpr.SelectedIds.Length; i++)
                            {
                                UserCharacter obus = new UserCharacter();
                                obus.User_Id = Convert.ToInt32(objpr.UserId);
                                obus.Character_Id = Convert.ToInt32(objpr.SelectedIds[i]);
                                ob.Add(obus);
                            }
                            context.UserCharacters.AddRange(ob);
                            context.SaveChanges();
                        }

                    }
                }
            }
            return RedirectToAction("Index", "ManageUsers");
        }
        private UserCharacterModel Getcharactername(List<UserCharacter> list)
        {
            UserCharacterModel obj = new UserCharacterModel();
            obj.characterlist = new List<string>();
            List<int> termsList = new List<int>();
            foreach (var item in list)
            {
                obj.characterlist.Add(item.Tbl_Character.Character_Name);
                obj.Character_Name += item.Tbl_Character.Character_Name + ",";
                obj.Id += item.Tbl_Character.Id + ",";
            }
            
            return obj;
        }
    }
}