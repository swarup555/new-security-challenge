﻿using Microsoft.AspNet.Identity;
using SecurityChallenge.FAI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SecurityChallenge.FAI.Controllers
{
    [Authorize(Roles = "Admin")]
    [HandleError]
    public class RolesController : Controller
    {
        // GET: Roles
        public ActionResult Index()
        {
            using (var context = new securitychallengeEntities())
            {
                var list = context.Tbl_Character.Select(m => new CharacterViewModel
                {
                    Id = m.Id,
                    Character_Name = m.Character_Name,
                    Description=m.Description
                }).ToList();
                return View(list);
            }
            
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index([Bind(Include = "Id,Character_Name,Description")] CharacterViewModel objpr)
        {
            using (var context = new securitychallengeEntities())
            {
                var list = context.Tbl_Character.Where(m => m.Character_Name == objpr.Character_Name).FirstOrDefault();
                if (list == null)
                {
                    Tbl_Character obj = new Tbl_Character();
                    obj.Character_Name = objpr.Character_Name;
                    obj.Description = objpr.Description;
                    var user = context.Tbl_Character.Add(obj);
                    context.SaveChanges();
                }
                else
                {
                    var objp = context.Tbl_Character.Select(m => new CharacterViewModel
                    {
                        Id = m.Id,
                        Character_Name = m.Character_Name,
                        Description = m.Description
                    }).ToList();
                    ModelState.AddModelError("", "Class Already in use");
                    return View(objp);
                }
            }
            return RedirectToAction("Index", "Roles");
        }
    }
}