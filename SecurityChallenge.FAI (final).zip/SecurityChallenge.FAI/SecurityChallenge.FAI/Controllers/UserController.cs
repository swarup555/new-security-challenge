﻿using Microsoft.AspNet.Identity;
using SecurityChallenge.FAI.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SecurityChallenge.FAI.Controllers
{
    [Authorize(Roles = "User")]
    [HandleError]
    public class UserController : Controller
    {
        // GET: User
        public ActionResult Index()
        {
            //UserViewModel ob = new UserViewModel();
            //ob.User = new List<UserDTO>();
            UserDTO obj = new UserDTO();
            using (var context = new securitychallengeEntities())
            {
                int userid = Convert.ToInt32(User.Identity.GetUserId());
                var item = context.USERS.Where(x => x.UserId == userid).FirstOrDefault();
                obj.UserId = item.UserId;
                obj.Username = item.UserName;
                obj.PhoneNumber = item.PhoneNumber;
                obj.Email = item.Email;
                obj.Character = Getcharactername(item.UserCharacters.ToList()).Character_Name;
                obj.CharacterId = Getcharactername(item.UserCharacters.ToList()).Id;
                obj.characterlist = Getcharacterlist(item.Tbl_User_Charcter.ToList());
                obj.MaxCharacter = item.MaxCharacter;
                //ob.Character = context.Tbl_Character.Select(x => new SelectListItem
                //{
                //    Value = x.Id.ToString(),
                //    Text = x.Character_Name
                //}).ToList();
            }
            return View(obj);
        }

        private List<string> Getcharacterlist(List<Tbl_User_Charcter> list)
        {
            List<string> characterlist = new List<string>();
            foreach (var item in list)
            {
                characterlist.Add(item.Description + ": " + item.Tbl_Character.Character_Name);
            }
            return characterlist;
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index([Bind(Include = "UserId,Email,PhoneNumber")] AddCharacter objpr)
        {
            using (var context = new securitychallengeEntities())
            {
                var obj = context.USERS.Where(x => x.UserId == objpr.UserId).FirstOrDefault();
                if (obj != null)
                {
                    obj.Email = objpr.Email;
                    obj.PhoneNumber = objpr.PhoneNumber;
                    var user = context.USERS.Add(obj);
                    context.Entry(obj).State = EntityState.Modified;
                    context.SaveChanges();
                }
            }
            return RedirectToAction("Index", "User");
        }
        private UserCharacterModel Getcharactername(List<UserCharacter> list)
        {
            UserCharacterModel obj = new UserCharacterModel();
            //obj.characterlist = new List<string>();
            List<int> termsList = new List<int>();
            foreach (var item in list)
            {
                //obj.characterlist.Add(item.Tbl_Character.Character_Name);
                obj.Character_Name += item.Tbl_Character.Character_Name + ",";
                obj.Id += item.Tbl_Character.Id + ",";
            }

            return obj;
        }
    }
}