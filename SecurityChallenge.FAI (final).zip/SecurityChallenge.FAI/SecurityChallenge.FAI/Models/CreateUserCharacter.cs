﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SecurityChallenge.FAI.Models
{
    public class CreateUserCharacter
    {
        public int Id { get; set; }
        public Nullable<int> Character_ID { get; set; }
        public string Character_Name { get; set; }
        public string Description { get; set; }
        public Nullable<int> User_ID { get; set; }
    }
}