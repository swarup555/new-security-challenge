﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SecurityChallenge.FAI.Models
{
    public class UserDTO
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PhoneNumber { get; set; }
        public bool IsActive { get; set; }
        public bool? LockoutEnabled { get; set; }
        public Nullable<int> MaxCharacter { get; set; }
        public System.DateTime CreateDate { get; set; }
        public System.DateTime? LockoutEndDateUtc { get; set; }
        public string RoleName { get; set; }
        public int RoleId { get; set; }
        public string Character { get; set; }
        public ICollection<UserCharacter> userCharacters { get; set; }
        public string CharacterId { get; set; }
        public List<string> characterlist { get; set; }
    }
  
}