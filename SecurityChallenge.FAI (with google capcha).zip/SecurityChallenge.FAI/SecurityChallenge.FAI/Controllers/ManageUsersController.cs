﻿using SecurityChallenge.FAI.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SecurityChallenge.FAI.Controllers
{
    [Authorize(Roles = "Admin")]
    [HandleError]
    public class ManageUsersController : Controller
    {
        // GET: ManageUsers
        public ActionResult Index()
        {
            UserViewModel ob = new UserViewModel();
            ob.User = new List<UserDTO>();
            using (var context = new securitychallengeEntities())
            {
                var list = context.USERS.Where(x=> x.UserRoles.FirstOrDefault().ROLE.RoleId!=4).ToList();
                foreach (var item in list)
                {
                    UserDTO obj = new UserDTO();
                    obj.UserId = item.UserId;
                    obj.Username = item.UserName;
                    obj.PhoneNumber = item.PhoneNumber;
                    obj.Email = item.Email;
                    obj.Character = Getcharactername(item.UserCharacters.ToList()).Character_Name;
                    obj.CharacterId= Getcharactername(item.UserCharacters.ToList()).Id;
                    ob.User.Add(obj);
                }
                ob.Character = context.Tbl_Character.Select(x => new SelectListItem
                {
                    Value = x.Id.ToString(),
                    Text = x.Character_Name
                }).ToList();
              
            }
            return View(ob);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index([Bind(Include = "UserId,Username,Email,PhoneNumber,SelectedIds")] AddCharacter objpr)
        {
            using (var context = new securitychallengeEntities())
            {
                if (objpr.UserId == null)
                {
                    USER obj = new USER();
                    obj.Email = objpr.Email;
                    obj.UserName = objpr.Username;
                    obj.PhoneNumber = objpr.PhoneNumber;
                    var user = context.USERS.Add(obj);
                    context.SaveChanges();
                    //UserRole role1 = new UserRole { RoleId = 5, UserId = user.UserId };
                    //context.UserRoles.Add(role1);
                    //context.SaveChanges();
                }
                else
                {
                    var obj = context.USERS.Where(x => x.UserId == objpr.UserId).FirstOrDefault();
                    if (obj != null)
                    {
                        obj.Email = objpr.Email;
                        obj.UserName = objpr.Username;
                        obj.PhoneNumber = objpr.PhoneNumber;
                        var user = context.USERS.Add(obj);
                        context.Entry(obj).State = EntityState.Modified;
                        context.SaveChanges();
                        var list = context.UserCharacters.Where(x => x.User_Id == objpr.UserId).ToList();
                        context.UserCharacters.RemoveRange(list);
                        context.SaveChanges();
                        List<UserCharacter> ob = new List<UserCharacter>();
                        if (objpr.SelectedIds != null)
                        {
                            for (int i = 0; i < objpr.SelectedIds.Length; i++)
                            {
                                UserCharacter obus = new UserCharacter();
                                obus.User_Id = Convert.ToInt32(objpr.UserId);
                                obus.Character_Id = Convert.ToInt32(objpr.SelectedIds[i]);
                                ob.Add(obus);
                            }
                            context.UserCharacters.AddRange(ob);
                            context.SaveChanges();
                        }

                    }
                }
            }
            return RedirectToAction("Index", "ManageUsers");
        }
        private UserCharacterModel Getcharactername(List<UserCharacter> list)
        {
            UserCharacterModel obj = new UserCharacterModel();
            obj.characterlist = new List<string>();
            List<int> termsList = new List<int>();
            foreach (var item in list)
            {
                obj.characterlist.Add(item.Tbl_Character.Character_Name);
                obj.Character_Name += item.Tbl_Character.Character_Name + ",";
                obj.Id += item.Tbl_Character.Id + ",";
            }
            
            return obj;
        }
    }
}