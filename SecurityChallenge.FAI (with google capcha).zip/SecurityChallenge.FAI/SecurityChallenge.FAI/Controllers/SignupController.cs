﻿using SecurityChallenge.FAI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SecurityChallenge.FAI.Controllers
{
    [Authorize]
    [HandleError]
    public class SignupController : Controller
    {
        // GET: Signup
        [AllowAnonymous]
        public ActionResult Index()
        {
            return View();
        }
        [AllowAnonymous]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index([Bind(Include = "Email,Username,PhoneNumber,Password,ConfirmPassword")] RegisterViewModel objpr)
        {
            using (var context = new securitychallengeEntities())
            {
                var usrename = context.USERS.Where(x => x.UserName == objpr.Username).FirstOrDefault();
                var email = context.USERS.Where(x => x.Email == objpr.Email).FirstOrDefault();
                if (usrename != null)
                {
                    ModelState.AddModelError("", "User Name already taken");
                    return View();
                }
                else if (email != null)
                {
                    ModelState.AddModelError("", "Email ID already in use");
                    return View();
                }
                else
                {
                    USER obj = new USER();
                    obj.Email = objpr.Email;
                    obj.UserName = objpr.Username;
                    obj.PhoneNumber = objpr.PhoneNumber;
                    obj.Inactive = false;
                    obj.PasswordHash = objpr.Password;
                    obj.LastModified = System.DateTime.Now;
                    obj.SecurityStamp = Guid.NewGuid().ToString();
                    var user = context.USERS.Add(obj);
                    context.SaveChanges();
                    UserRole role1 = new UserRole { RoleId = 5, UserId = user.UserId };
                    context.UserRoles.Add(role1);
                    context.SaveChanges();
                   
                }
            }
            return RedirectToAction("Signupconfimation", "Signup");
        }
        [AllowAnonymous]
        public ActionResult Signupconfimation()
        {
            return View();
        }
    }
}