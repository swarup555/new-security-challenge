﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SecurityChallenge.FAI.Models
{
    public class UserCharacterModel
    {
        public string Character_Name { get; set; }
        public string Id { get; set; }

        public List<string> characterlist { get; set; }
    }
}