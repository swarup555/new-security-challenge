﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SecurityChallenge.FAI.Models
{
    public class UserViewModel
    {
        public List<UserDTO> User { get; set; }
        public int[] SelectedIds { get; set; }
        public IEnumerable<SelectListItem> Character { get; set; }
        //public List<CharacterViewModel> Character { get; set; }
    }
}