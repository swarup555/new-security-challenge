﻿using Newtonsoft.Json;
using SecurityChallenge.FAI.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.Linq;
using System.Net.Mail;
using System.Security.Claims;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace SecurityChallenge.FAI.Controllers
{
    [Authorize]
    [HandleError]
    public class LoginController : Controller
    {
        private static string EmailId = ConfigurationManager.AppSettings["EmailId"];
        // GET: Login
        [AllowAnonymous]
        public ActionResult Index()
        {
            if (Request.IsAuthenticated)
            {
                return RedirectToAction("Index", "Home");
            }
            return View();
        }
        [AllowAnonymous]
        public ActionResult Lockout()
        {
            return View();
        }

        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult Index([Bind(Include = "Email,Password")] LoginViewModel model, string returnUrl)
        {
            this.Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            this.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            this.Response.Cache.SetNoStore();

            using (var context = new securitychallengeEntities())
            {
                var data = context.USERS.Where(x => x.UserName == model.Email)
                                     .Select(x => new UserDTO
                                     {
                                         UserId = x.UserId,
                                         FirstName = x.Firstname,
                                         LastName = x.Lastname,
                                         Email = x.Email,
                                         Password = x.PasswordHash,
                                         Username = x.UserName,
                                         LockoutEnabled = x.LockoutEnabled,
                                         LockoutEndDateUtc = x.LockoutEndDateUtc,
                                         RoleName = x.UserRoles.FirstOrDefault().ROLE.Name,
                                         RoleId = x.UserRoles.FirstOrDefault().ROLE.RoleId
                                     }).FirstOrDefault();


                if (data != null)
                {
                    if (data.Password== model.Password)
                    {
                        if (data.LockoutEnabled == true)
                        {
                            if (data.LockoutEndDateUtc < System.DateTime.Now)
                            {
                                var result = context.USERS.Where(x => x.UserName == model.Email).FirstOrDefault();
                                if (result != null)
                                {
                                    result.LockoutEnabled = false;
                                    context.Entry(result).State = EntityState.Modified;
                                    context.SaveChanges();
                                }
                            }
                            else
                            {
                                return RedirectToAction("Lockout", "login");
                            }
                        }
                        //var claims = claimsRepository.GetClaimsForUser(data.Username, data.RoleName);
                        //claims.Add(new Claim(ClaimTypes.Role, Role));
                        var claims = new List<Claim>
                    {
                        new Claim(ClaimTypes.Name, data.Username),
                        new Claim(ClaimTypes.Email, data.Email),
                        new Claim(ClaimTypes.Role,data.RoleName),
                        new Claim(ClaimTypes.NameIdentifier,Convert.ToString(data.UserId)), //should be userid
                    }; 
                        var ci = new ClaimsIdentity(claims, "Cookie");
                        FormsAuthentication.SetAuthCookie(data.Username, true);
                        string[] roles = { data.RoleName };
                        CustomPrincipalSerializeModel serializeModel = new CustomPrincipalSerializeModel
                        {
                            UserId = data.UserId,
                            FirstName = data.FirstName,
                            LastName = data.LastName,
                            roles = roles
                        };
                        string userData = JsonConvert.SerializeObject(serializeModel);
                        FormsAuthenticationTicket authTicket = new FormsAuthenticationTicket(
                                 1,
                                 data.Email,
                                 DateTime.Now,
                                 DateTime.Now.AddMinutes(15),
                                 false,
                                 userData);

                        string encTicket = FormsAuthentication.Encrypt(authTicket);
                        HttpCookie faCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encTicket);
                        Response.Cookies.Add(faCookie);
                        var ctx = Request.GetOwinContext();
                        ctx.Authentication.SignIn(ci);
                        if (Url.IsLocalUrl(returnUrl))
                        {
                            return Redirect(returnUrl);
                        }

                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        var result = context.USERS.Where(x => x.UserName == model.Email).FirstOrDefault();
                        if (result != null)
                        {
                            if (result.LockoutEnabled == true)
                            {
                                if (data.LockoutEndDateUtc < System.DateTime.Now)
                                {
                                    result.LockoutEnabled = false;
                                    context.Entry(result).State = EntityState.Modified;
                                    context.SaveChanges();
                                }
                                else
                                {
                                    int days = 1;
                                    result.LockoutEndDateUtc = DateTime.Now.AddDays(days);
                                    result.LastModified = System.DateTime.Now;
                                    context.Entry(result).State = EntityState.Modified;
                                    context.SaveChanges();
                                    return RedirectToAction("Lockout", "login");
                                }
                            }


                            if (result.AccessFailedCount == 3)
                            {
                                result.LastModified = System.DateTime.Now;
                                int days = 1;
                                result.AccessFailedCount = 0;
                                result.LockoutEnabled = true;
                                result.LockoutEndDateUtc = DateTime.Now.AddDays(days);
                            }
                            else
                            {
                                result.LastModified = System.DateTime.Now;
                                result.AccessFailedCount = result.AccessFailedCount == null ? 1 : result.AccessFailedCount + 1;
                                result.LockoutEnabled = false;
                            }
                            context.Entry(result).State = EntityState.Modified;
                            context.SaveChanges();
                            ModelState.AddModelError("", "Invalid password");
                            return View();
                        }
                        return View();
                    }
                }
                else
                {
                    ModelState.AddModelError("", "Invalid Username or Password");
                    return View();
                }

            }
        }

        public ActionResult resetpasword()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult resetpasword([Bind(Include = "OldPassword,NewPassword,ConfirmPassword")] ResetPasswordViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            using (var context = new securitychallengeEntities())
            {
                var result = context.USERS.Where(x => x.PasswordHash == model.OldPassword).FirstOrDefault();
                if (result != null)
                {
                    result.LastModified = System.DateTime.Now;
                    result.PasswordHash = model.NewPassword;
                    context.Entry(result).State = EntityState.Modified;
                    context.SaveChanges();
                    Session.Clear();
                    Session.Abandon();
                    Session.RemoveAll();
                    FormsAuthentication.SignOut();
                    var ctx = Request.GetOwinContext();
                    ctx.Authentication.SignOut();
                    Response.Cookies.Clear();
                    this.Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
                    this.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                    this.Response.Cache.SetNoStore();
                    return RedirectToAction("resetpaswordconfirmation", "login");
                }
            }
            ModelState.AddModelError("", "Invalid Password");
            return View();
        }
        [AllowAnonymous]
        public ActionResult resetpaswordExternal(string username, string code)
        {
            if (username == code)
            {
                return View();
            }
            return RedirectToAction("index", "Login");
        }
        [AllowAnonymous]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult resetpaswordExternal([Bind(Include = "Email,NewPassword,ConfirmPassword")] ResetPasswordViewModel model)
        {
            using (var context = new securitychallengeEntities())
            {
                var result = context.USERS.Where(x => x.Email == model.Email).FirstOrDefault();
                if (result != null)
                {
                    result.LastModified = System.DateTime.Now;
                    result.PasswordHash = model.NewPassword;
                    context.Entry(result).State = EntityState.Modified;
                    context.SaveChanges();
                    Session.Clear();
                    Session.Abandon();
                    Session.RemoveAll();
                    FormsAuthentication.SignOut();
                    var ctx = Request.GetOwinContext();
                    ctx.Authentication.SignOut();
                    Response.Cookies.Clear();
                    this.Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
                    this.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                    this.Response.Cache.SetNoStore();
                    return View("resetpaswordconfirmation");
                }
            }
            ModelState.AddModelError("", "Invalid Email ID");
            return View();
        }
        [AllowAnonymous]
        public ActionResult resetpaswordconfirmation()
        {
            return View();
        }
        [AllowAnonymous]
        public ActionResult ForgotPassword()
        {
            return View();
        }
        [AllowAnonymous]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ForgotPassword([Bind(Include = "Email")] ForgotViewModel obj)
        {
            string code = obj.Email;
            var callbackUrl = Url.Action("resetpaswordExternal", "login", new { userId = obj.Email, code = code }, protocol: Request.Url.Scheme);
            sendEmail(obj.Email, callbackUrl);
            return View("ForgotPasswordconfirmation");
        }
        [AllowAnonymous]
        public ActionResult ForgotPasswordconfirmation()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            Session.Clear();
            Session.Abandon();
            Session.RemoveAll();
            FormsAuthentication.SignOut();
            var ctx = Request.GetOwinContext();
            ctx.Authentication.SignOut();
            Response.Cookies.Clear();
            this.Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            this.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            this.Response.Cache.SetNoStore();
            return RedirectToAction("index", "Login");
        }
        private bool sendEmail(string tomail, string message)
        {
            bool status = true;
            try
            {
                MailMessage mail = new MailMessage();
                mail.From = new MailAddress(EmailId);
                mail.Subject = "Password reset link";
                mail.Body = message;
                mail.IsBodyHtml = true;
                SmtpClient smtp = null;
                mail.To.Add(tomail);
                smtp = new SmtpClient("mail.firstam.com");
                smtp.Send(mail);
                mail.To.Clear();
                status = true;
            }
            catch (Exception ex)
            {
                status = false;
            }
            return status;
        }
    }
}