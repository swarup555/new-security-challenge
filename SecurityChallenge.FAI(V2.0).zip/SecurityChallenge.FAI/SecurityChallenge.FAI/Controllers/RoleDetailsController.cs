﻿using SecurityChallenge.FAI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SecurityChallenge.FAI.Controllers
{
    [Authorize(Roles = "User")]
    [HandleError]
    public class RoleDetailsController : Controller
    {
        // GET: RoleDetails
        public ActionResult Index()
        {
            using (var context = new securitychallengeEntities())
            {
                var list = context.Tbl_Character.Select(m => new CharacterViewModel
                {
                    Id = m.Id,
                    Character_Name = m.Character_Name,
                    Description = m.Description
                }).ToList();
                return View(list);
            }
        }
    }
}